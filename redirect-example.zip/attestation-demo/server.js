require('dotenv').config()

const express = require("express");
const session = require("express-session");
const ExpressOIDC = require("@okta/oidc-middleware").ExpressOIDC;

let app = express();

// Globals
const OKTA_ISSUER_URI = process.env.OKTA_AUTHZ_SERVER;
const OKTA_CLIENT_ID = process.env.OKTA_CLIENT_ID;
const OKTA_CLIENT_SECRET = process.env.OKTA_CLIENT_SECRET;
const REDIRECT_URI = process.env.REDIRECT_URI;
const PORT = process.env.PORT || "3000";
const SECRET = process.env.SECRET;

// App settings
app.set("view engine", "pug");

// App middleware
app.use("/static", express.static("static"));

app.use(session({
  cookie: { httpOnly: true },
  secret: process.env.SESSION_SECRET
}));

let oidc = new ExpressOIDC({
  issuer: process.env.OKTA_AUTHZ_SERVER,
  client_id: process.env.OKTA_CLIENT_ID,
  client_secret: process.env.OKTA_CLIENT_SECRET,
  appBaseUrl: process.env.OKTA_REDIRECT_URI,
  redirect_uri: process.env.OKTA_REDIRECT_URI,
  routes: { loginCallback: { afterCallback: "/dashboard" } },
  scope: 'openid profile'
});

app.use(function (req, res, next) {
  res.setHeader('spaghetti', true)
  next()
})

// App routes
app.use(oidc.router);

// app.get("/", (req, res) => {
//   res.render("index");
// });

// app.get("/dashboard", oidc.ensureAuthenticated(), (req, res) => {
//   res.render("dashboard", {
//     user: req.userContext.userinfo,
//     token: req.userContext.tokens.id_token
//   });
// });

// app.get("/attestation", oidc.ensureAuthenticated(), (req, res) => {
//   var login_hint = req.userContext.userinfo.preferred_username;
//   var oauth_nonce = "";

//   //generate a reasonable nonce
//   var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
//   for (var i = 0; i < 13; i++) {
//     oauth_nonce += possible.charAt(Math.floor(Math.random() * possible.length));
//   }

//   var nJwt = require('njwt');

//   var request = {
//     iss: process.env.OKTA_CLIENT_ID,
//     aud: OKTA_ISSUER_URI,
//     response_type: 'code',
//     client_id: process.env.OKTA_CLIENT_ID,
//     response_mode: 'fragment',
//     test: "test", //location, context 
//     nonce: oauth_nonce,
//     scope: 'openid',
//     state: 'demo',
//     login_hint: login_hint,
//     redirect_uri: "http://localhost:" + PORT + "/attestation/callback"
//   }



//   var signedRequest = nJwt.create(request, process.env.OKTA_CLIENT_SECRET);
//   console.log(signedRequest)
//   var redirectLink = `${OKTA_ISSUER_URI}/v1/authorize?request=` + signedRequest
//   console.log(redirectLink)
//   res.redirect(redirectLink);
// });

app.get("/authn", (req, res) => {
  console.log(req.query)
  var oauth_nonce = "";

  //generate a reasonable nonce
  var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  for (var i = 0; i < 13; i++) {
    oauth_nonce += possible.charAt(Math.floor(Math.random() * possible.length));
  }

  var nJwt = require('njwt');
  var stateObject = JSON.stringify({state: oauth_nonce, origin: req.query.location})

  var request = {
    iss: process.env.OKTA_CLIENT_ID,
    aud: OKTA_ISSUER_URI,
    response_type: 'code',
    client_id: process.env.OKTA_CLIENT_ID,
    test: "test",
    scope: 'openid',
    state: stateObject,
    redirect_uri: "http://localhost:" + PORT + "/attestation/callback"
  }



  var signedRequest = nJwt.create(request, process.env.OKTA_CLIENT_SECRET);
  console.log(signedRequest)
  var redirectLink = `${OKTA_ISSUER_URI}/v1/authorize?request=${signedRequest}&sessionToken=${req.query.sessionToken}`
  console.log(redirectLink)
  res.redirect(redirectLink);
});

app.get("/attestation/callback", async (req, res) => {
  console.log(req.query)
  console.log(req.query.code)
  var state = JSON.parse(req.query.state)
  var location = state.origin
  console.log("location", location, state)
  res.redirect(location + '/login?code=' + req.query.code);
});

app.get("/logout", (req, res) => {
  req.logout();
  res.redirect("/");
});

oidc.on("ready", () => {
  console.log("Server running on port: " + PORT);
  app.listen(parseInt(PORT));
});

oidc.on("error", err => {
  console.error(err);
});